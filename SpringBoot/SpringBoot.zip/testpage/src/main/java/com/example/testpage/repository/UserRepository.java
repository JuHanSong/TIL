package com.example.testpage.repository;
import org.springframework.data.repository.CrudRepository;

import org.apache.catalina.User;

import java.util.List;

public interface UserRepository extends CrudRepository<User, String>{
    List<User> findAll();

}
