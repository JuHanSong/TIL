package com.example.testpage.controller;

import com.example.testpage.service.UserService;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping

public class MainController {

    @Autowired
    UserService userService;

    @GetMapping(value = "getuser")
    public List<User> getUser(){
        return userService.findAllUsers();
    }

}
