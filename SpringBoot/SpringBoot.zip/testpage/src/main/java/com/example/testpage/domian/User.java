package com.example.testpage.domian;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "user")

public class User {
    @Id
    @Column(name = "USER_Num")
    private String userNum;
    @Column(name = "User_Name")
    private String userName;
    @Column(name = "User_ID")
    private String userId;
    @Column(name = "User_PW")
    private String userPw;
    @Column(name = "User_TEL")
    private String userTel;

}